/**
 * TXW interfaces for writing episode file, which is what XJC needs to
 * handle separate compilation.
 */
@XmlNamespace(WellKnownNamespace.JAXB)
package com.sun.xml.bind.v2.schemagen.episode;

import com.sun.xml.txw2.annotation.XmlNamespace;
import com.sun.xml.bind.v2.WellKnownNamespace;